package com.dzcast.app.model

import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

enum class GlassAccentMode(val labelAr: String) {
    DUAL_BLEND("مزيج أحمر وأزرق"),
    MUTED_CRIMSON("أحمر خافت"),
    SAPPHIRE_BLUE("أزرق زجاجي")
}

enum class MirrorQuality(
    val label: String,
    val subtitle: String,
    val width: Int,
    val height: Int,
    val defaultFps: Int,
    val defaultJpegQuality: Int
) {
    LOW_360P("360p", "توفير الشبكة", 640, 360, 15, 55),
    MEDIUM_480P("480p", "متوازن وسريع", 854, 480, 20, 65),
    HD_720P("720p HD", "موصى به", 1280, 720, 25, 75),
    FHD_1080P("1080p FHD", "جودة فائقة", 1920, 1080, 30, 82)
}

data class DetectedMedia(
    val url: String,
    val title: String,
    val type: String, // HLS, MP4, AUDIO, DASH
    val detectedAt: Long = System.currentTimeMillis()
)

data class DlnaDevice(
    val name: String,
    val location: String,
    val controlUrl: String,
    val host: String
)

data class IptvChannel(
    val name: String,
    val group: String,
    val url: String
)

data class BookmarkItem(
    val title: String,
    val url: String
)

data class ActiveCastMedia(
    val title: String = "",
    val url: String = "",
    val mimeType: String = "video/mp4",
    val isLocal: Boolean = false,
    val localUri: Uri? = null,
    val isPlaying: Boolean = false,
    val volume: Int = 80,
    val command: String = "IDLE", // LOAD, PLAY, PAUSE, STOP, SEEK
    val seekDeltaSec: Int = 0,
    val commandSeq: Long = 0L
)

data class AppUiState(
    val accentMode: GlassAccentMode = GlassAccentMode.DUAL_BLEND,
    val localIp: String = "127.0.0.1",
    val serverPort: Int = 8080,
    val isServerRunning: Boolean = false,
    val isMirroring: Boolean = false,
    val mirrorQuality: MirrorQuality = MirrorQuality.HD_720P,
    val mirrorFps: Int = 25,
    val mirrorJpegQuality: Int = 75,
    val mirrorFramesSent: Long = 0L,
    val detectedMedia: List<DetectedMedia> = emptyList(),
    val blockedAdsCount: Int = 0,
    val dlnaDevices: List<DlnaDevice> = emptyList(),
    val selectedDlnaDevice: DlnaDevice? = null,
    val isScanningDevices: Boolean = false,
    val activeCast: ActiveCastMedia = ActiveCastMedia(),
    val iptvChannels: List<IptvChannel> = emptyList(),
    val bookmarks: List<BookmarkItem> = listOf(
        BookmarkItem("Google", "https://www.google.com"),
        BookmarkItem("YouTube Mobile", "https://m.youtube.com"),
        BookmarkItem("Dailymotion", "https://www.dailymotion.com"),
        BookmarkItem("Vimeo", "https://vimeo.com")
    ),
    val statusMessage: String = "جاهز للبث — خالٍ تماماً من الإعلانات 🇩🇿"
)

object CastStateHolder {
    private val _state = MutableStateFlow(AppUiState())
    val state: StateFlow<AppUiState> = _state.asStateFlow()

    val latestMirrorFrame = AtomicReference<ByteArray?>(null)
    val latestFrameCounter = AtomicLong(0L)

    fun update(block: (AppUiState) -> AppUiState) {
        _state.update(block)
    }

    fun addDetectedMedia(media: DetectedMedia) {
        _state.update { current ->
            if (current.detectedMedia.any { it.url == media.url }) {
                current
            } else {
                current.copy(detectedMedia = listOf(media) + current.detectedMedia.take(29))
            }
        }
    }

    fun incrementBlockedAds() {
        _state.update { it.copy(blockedAdsCount = it.blockedAdsCount + 1) }
    }

    fun clearDetectedMedia() {
        _state.update { it.copy(detectedMedia = emptyList()) }
    }

    fun setActiveWebMedia(title: String, url: String, mimeType: String) {
        _state.update { current ->
            current.copy(
                activeCast = ActiveCastMedia(
                    title = title,
                    url = url,
                    mimeType = mimeType,
                    isLocal = false,
                    localUri = null,
                    isPlaying = true,
                    volume = current.activeCast.volume,
                    command = "LOAD",
                    commandSeq = current.activeCast.commandSeq + 1
                ),
                statusMessage = "جاري بث: $title"
            )
        }
    }

    fun setActiveLocalMedia(title: String, uri: Uri, mimeType: String) {
        _state.update { current ->
            val streamUrl = "http://${current.localIp}:${current.serverPort}/media/local?t=${System.currentTimeMillis()}"
            current.copy(
                activeCast = ActiveCastMedia(
                    title = title,
                    url = streamUrl,
                    mimeType = mimeType,
                    isLocal = true,
                    localUri = uri,
                    isPlaying = true,
                    volume = current.activeCast.volume,
                    command = "LOAD",
                    commandSeq = current.activeCast.commandSeq + 1
                ),
                statusMessage = "جاري بث الملف المحلي: $title"
            )
        }
    }

    fun sendRemoteCommand(cmd: String, seekDelta: Int = 0, newVolume: Int? = null) {
        _state.update { current ->
            val playing = when (cmd) {
                "PLAY" -> true
                "PAUSE", "STOP" -> false
                else -> current.activeCast.isPlaying
            }
            current.copy(
                activeCast = current.activeCast.copy(
                    isPlaying = playing,
                    volume = newVolume ?: current.activeCast.volume,
                    command = cmd,
                    seekDeltaSec = seekDelta,
                    commandSeq = current.activeCast.commandSeq + 1
                )
            )
        }
    }
}
