package com.dzcast.app.network

import com.dzcast.app.model.DlnaDevice
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URL

object DlnaManager {

    private const val SSDP_ADDRESS = "239.255.255.250"
    private const val SSDP_PORT = 1900

    suspend fun discoverDevices(timeoutMs: Int = 2600): List<DlnaDevice> = withContext(Dispatchers.IO) {
        val foundLocations = LinkedHashSet<String>()
        val searchPayload = (
            "M-SEARCH * HTTP/1.1\r\n" +
                "HOST: 239.255.255.250:1900\r\n" +
                "MAN: "ssdp:discover"\r\n" +
                "MX: 2\r\n" +
                "ST: urn:schemas-upnp-org:device:MediaRenderer:1\r\n\r\n"
            ).toByteArray()

        var socket: DatagramSocket? = null
        try {
            socket = DatagramSocket().apply {
                soTimeout = 700
                reuseAddress = true
            }
            val group = InetAddress.getByName(SSDP_ADDRESS)
            val sendPacket = DatagramPacket(searchPayload, searchPayload.size, group, SSDP_PORT)
            socket.send(sendPacket)

            val deadline = System.currentTimeMillis() + timeoutMs
            val buffer = ByteArray(4096)
            while (System.currentTimeMillis() < deadline) {
                try {
                    val recvPacket = DatagramPacket(buffer, buffer.size)
                    socket.receive(recvPacket)
                    val response = String(recvPacket.data, 0, recvPacket.length)
                    response.lines().forEach { line ->
                        if (line.startsWith("LOCATION:", ignoreCase = true)) {
                            val loc = line.substringAfter(":").trim()
                            if (loc.startsWith("http")) foundLocations.add(loc)
                        }
                    }
                } catch (_: SocketTimeoutException) {
                    // continue until deadline
                }
            }
        } catch (_: Exception) {
            // ignore discovery network errors
        } finally {
            socket?.close()
        }

        val devices = mutableListOf<DlnaDevice>()
        for (location in foundLocations) {
            parseDeviceDescription(location)?.let { devices.add(it) }
        }
        devices
    }

    private fun parseDeviceDescription(location: String): DlnaDevice? {
        return try {
            val url = URL(location)
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 2000
                readTimeout = 2000
                requestMethod = "GET"
            }
            val xml = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val friendlyName = Regex("<friendlyName>(.*?)</friendlyName>", RegexOption.IGNORE_CASE)
                .find(xml)?.groupValues?.getOrNull(1)?.trim() ?: url.host

            val avServiceBlock = Regex(
                "<service>.*?AVTransport:1.*?</service>",
                setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
            ).find(xml)?.value ?: return null

            val rawControlUrl = Regex("<controlURL>(.*?)</controlURL>", RegexOption.IGNORE_CASE)
                .find(avServiceBlock)?.groupValues?.getOrNull(1)?.trim() ?: return null

            val fullControlUrl = if (rawControlUrl.startsWith("http")) {
                rawControlUrl
            } else {
                val base = "${url.protocol}://${url.host}:${if (url.port > 0) url.port else 80}"
                if (rawControlUrl.startsWith("/")) "$base$rawControlUrl" else "$base/$rawControlUrl"
            }

            DlnaDevice(
                name = friendlyName,
                location = location,
                controlUrl = fullControlUrl,
                host = url.host
            )
        } catch (_: Exception) {
            null
        }
    }

    suspend fun castMediaToDevice(device: DlnaDevice, mediaUrl: String, title: String): Boolean =
        withContext(Dispatchers.IO) {
            val escapedUrl = escapeXml(mediaUrl)
            val escapedTitle = escapeXml(title.ifBlank { "DZ Cast Media" })
            val setUriBody = """
                <?xml version="1.0" encoding="utf-8"?>
                <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
                  <s:Body>
                    <u:SetAVTransportURI xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                      <InstanceID>0</InstanceID>
                      <CurrentURI>$escapedUrl</CurrentURI>
                      <CurrentURIMetaData>&lt;DIDL-Lite xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/" xmlns:dc="http://purl.org/dc/elements/1.1/"&gt;&lt;item id="0" parentID="-1" restricted="1"&gt;&lt;dc:title&gt;$escapedTitle&lt;/dc:title&gt;&lt;/item&gt;&lt;/DIDL-Lite&gt;</CurrentURIMetaData>
                    </u:SetAVTransportURI>
                  </s:Body>
                </s:Envelope>
            """.trimIndent()

            val setOk = sendSoap(device.controlUrl, "SetAVTransportURI", setUriBody)
            if (!setOk) return@withContext false
            play(device)
        }

    suspend fun play(device: DlnaDevice): Boolean = withContext(Dispatchers.IO) {
        val body = """
            <?xml version="1.0" encoding="utf-8"?>
            <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
              <s:Body>
                <u:Play xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                  <InstanceID>0</InstanceID>
                  <Speed>1</Speed>
                </u:Play>
              </s:Body>
            </s:Envelope>
        """.trimIndent()
        sendSoap(device.controlUrl, "Play", body)
    }

    suspend fun pause(device: DlnaDevice): Boolean = withContext(Dispatchers.IO) {
        val body = """
            <?xml version="1.0" encoding="utf-8"?>
            <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
              <s:Body>
                <u:Pause xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                  <InstanceID>0</InstanceID>
                </u:Pause>
              </s:Body>
            </s:Envelope>
        """.trimIndent()
        sendSoap(device.controlUrl, "Pause", body)
    }

    suspend fun stop(device: DlnaDevice): Boolean = withContext(Dispatchers.IO) {
        val body = """
            <?xml version="1.0" encoding="utf-8"?>
            <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
              <s:Body>
                <u:Stop xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
                  <InstanceID>0</InstanceID>
                </u:Stop>
              </s:Body>
            </s:Envelope>
        """.trimIndent()
        sendSoap(device.controlUrl, "Stop", body)
    }

    private fun sendSoap(controlUrl: String, action: String, xmlBody: String): Boolean {
        return try {
            val conn = (URL(controlUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 3000
                readTimeout = 3000
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Content-Type", "text/xml; charset="utf-8"")
                setRequestProperty("SOAPACTION", ""urn:schemas-upnp-org:service:AVTransport:1#$action"")
            }
            conn.outputStream.use { it.write(xmlBody.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            conn.disconnect()
            code in 200..299
        } catch (_: Exception) {
            false
        }
    }

    private fun escapeXml(input: String): String =
        input.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace(""", "&quot;")
            .replace("'", "&apos;")
}
