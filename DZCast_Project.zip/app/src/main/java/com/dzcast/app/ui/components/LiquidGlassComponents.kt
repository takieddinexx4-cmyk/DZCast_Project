package com.dzcast.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dzcast.app.model.GlassAccentMode
import com.dzcast.app.ui.theme.GlassFill
import com.dzcast.app.ui.theme.GlassFillStrong
import com.dzcast.app.ui.theme.GlassWhiteHigh
import com.dzcast.app.ui.theme.GlassWhiteLow
import com.dzcast.app.ui.theme.ObsidianBlack
import com.dzcast.app.ui.theme.paletteFor

@Composable
fun AmbientLiquidBackground(
    accentMode: GlassAccentMode,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val palette = paletteFor(accentMode)
    Box(modifier = modifier.fillMaxSize().background(ObsidianBlack)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(palette.topOrb.copy(alpha = 0.42f), Color.Transparent),
                    center = Offset(size.width * 0.18f, size.height * 0.14f),
                    radius = size.width * 0.85f
                ),
                center = Offset(size.width * 0.18f, size.height * 0.14f),
                radius = size.width * 0.85f
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(palette.bottomOrb.copy(alpha = 0.44f), Color.Transparent),
                    center = Offset(size.width * 0.85f, size.height * 0.82f),
                    radius = size.width * 0.90f
                ),
                center = Offset(size.width * 0.85f, size.height * 0.82f),
                radius = size.width * 0.90f
            )
        }
        content()
    }
}

@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 26.dp,
    strong: Boolean = false,
    tint: Color = Color.Transparent,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    val fillBrush = Brush.linearGradient(
        colors = listOf(
            if (strong) GlassFillStrong else GlassFill,
            tint.copy(alpha = if (tint == Color.Transparent) 0f else 0.14f),
            Color(0x0AFFFFFF)
        )
    )
    val borderBrush = Brush.linearGradient(
        colors = listOf(
            GlassWhiteHigh,
            GlassWhiteLow,
            Color(0x22FFFFFF)
        )
    )
    Box(
        modifier = modifier
            .clip(shape)
            .background(fillBrush)
            .border(width = 1.dp, brush = borderBrush, shape = shape),
        content = content
    )
}

@Composable
fun LiquidGlassButton(
    text: String,
    emoji: String,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = true
) {
    val shape = RoundedCornerShape(20.dp)
    val bgBrush = if (selected) {
        Brush.horizontalGradient(
            listOf(
                accentColor.copy(alpha = 0.78f),
                accentColor.copy(alpha = 0.48f)
            )
        )
    } else {
        Brush.horizontalGradient(listOf(GlassFill, Color(0x0DFFFFFF)))
    }
    Row(
        modifier = modifier
            .clip(shape)
            .background(bgBrush)
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(listOf(GlassWhiteHigh, GlassWhiteLow)),
                shape = shape
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = emoji, fontSize = 16.sp)
        Text(
            text = "  $text",
            color = Color.White,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp
        )
    }
}
