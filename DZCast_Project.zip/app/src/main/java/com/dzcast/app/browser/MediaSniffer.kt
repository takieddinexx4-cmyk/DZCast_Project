package com.dzcast.app.browser

import com.dzcast.app.model.DetectedMedia

object MediaSniffer {

    fun inspectUrl(url: String, pageTitle: String?): DetectedMedia? {
        val lower = url.lowercase()
        val clean = lower.substringBefore("?")
        val type = when {
            clean.endsWith(".m3u8") || lower.contains(".m3u8?") -> "HLS"
            clean.endsWith(".mp4") || lower.contains(".mp4?") -> "MP4"
            clean.endsWith(".mpd") || lower.contains(".mpd?") -> "DASH"
            clean.endsWith(".webm") -> "WEBM"
            clean.endsWith(".mkv") -> "MKV"
            clean.endsWith(".mp3") || clean.endsWith(".m4a") || clean.endsWith(".aac") -> "AUDIO"
            else -> return null
        }

        val nameFromUrl = url.substringBefore("?").substringAfterLast("/").take(42)
        val displayTitle = when {
            !pageTitle.isNullOrBlank() -> "${pageTitle.take(36)} ($type)"
            nameFromUrl.isNotBlank() -> nameFromUrl
            else -> "فيديو مكتشف ($type)"
        }
        return DetectedMedia(url = url, title = displayTitle, type = type)
    }

    const val JS_SCANNER = """
        (function() {
            try {
                var nodes = document.querySelectorAll('video, source, audio');
                nodes.forEach(function(el) {
                    var src = el.currentSrc || el.src;
                    if (src && src.indexOf('http') === 0) {
                        window.DZCastBridge.onMediaFound(src, document.title || 'Web Video');
                    }
                });
            } catch(e) {}
        })();
    """
}
