package com.dzcast.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.dzcast.app.model.CastStateHolder
import com.dzcast.app.network.LocalCastServer
import com.dzcast.app.network.NetworkUtils

class CastServerService : Service() {

    private var server: LocalCastServer? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val ip = NetworkUtils.getLocalIpAddress()
        val notif = buildNotification("خادم البث نشط على http://$ip:8080")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notif)
        }

        server = LocalCastServer(applicationContext, PORT).also { it.start() }
        CastStateHolder.update {
            it.copy(localIp = ip, serverPort = PORT, isServerRunning = true)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ip = NetworkUtils.getLocalIpAddress()
        CastStateHolder.update { it.copy(localIp = ip, isServerRunning = true) }
        return START_STICKY
    }

    override fun onDestroy() {
        server?.stop()
        CastStateHolder.update { it.copy(isServerRunning = false) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "DZ Cast Local Server",
            NotificationManager.IMPORTANCE_LOW
        )
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("DZ Cast 🇩🇿")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val PORT = 8080
        private const val CHANNEL_ID = "dzcast_server_channel"
        private const val NOTIF_ID = 1001
    }
}
