package com.dzcast.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.dzcast.app.model.GlassAccentMode

val ObsidianBlack = Color(0xFF06070C)
val DeepSlate = Color(0xFF0D101A)
val MutedCrimson = Color(0xFFC43B4E)
val SoftCrimsonGlow = Color(0xFF8C2434)
val SapphireBlue = Color(0xFF2F6BC7)
val DeepBlueGlow = Color(0xFF1A3E78)
val GlassWhiteHigh = Color(0x38FFFFFF)
val GlassWhiteLow = Color(0x0DFFFFFF)
val GlassFill = Color(0x16FFFFFF)
val GlassFillStrong = Color(0x22FFFFFF)
val TextPrimary = Color(0xFFF5F7FA)
val TextSecondary = Color(0xFFA7B0C2)

data class LiquidPalette(
    val primary: Color,
    val secondary: Color,
    val topOrb: Color,
    val bottomOrb: Color
)

fun paletteFor(mode: GlassAccentMode): LiquidPalette = when (mode) {
    GlassAccentMode.DUAL_BLEND -> LiquidPalette(
        primary = MutedCrimson,
        secondary = SapphireBlue,
        topOrb = SoftCrimsonGlow,
        bottomOrb = DeepBlueGlow
    )
    GlassAccentMode.MUTED_CRIMSON -> LiquidPalette(
        primary = MutedCrimson,
        secondary = Color(0xFF7A2030),
        topOrb = SoftCrimsonGlow,
        bottomOrb = Color(0xFF47121C)
    )
    GlassAccentMode.SAPPHIRE_BLUE -> LiquidPalette(
        primary = SapphireBlue,
        secondary = Color(0xFF1F4D96),
        topOrb = DeepBlueGlow,
        bottomOrb = Color(0xFF102A54)
    )
}

@Composable
fun DZCastTheme(
    accentMode: GlassAccentMode,
    content: @Composable () -> Unit
) {
    val palette = paletteFor(accentMode)
    val colorScheme = darkColorScheme(
        primary = palette.primary,
        secondary = palette.secondary,
        background = ObsidianBlack,
        surface = DeepSlate,
        onPrimary = Color.White,
        onSecondary = Color.White,
        onBackground = TextPrimary,
        onSurface = TextPrimary
    )
    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
