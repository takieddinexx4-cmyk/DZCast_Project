package com.dzcast.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dzcast.app.model.AppUiState
import com.dzcast.app.ui.components.LiquidGlassButton
import com.dzcast.app.ui.components.LiquidGlassCard
import com.dzcast.app.ui.theme.TextSecondary
import com.dzcast.app.ui.theme.paletteFor

@Composable
fun LocalMediaScreen(
    uiState: AppUiState,
    onPickVideo: () -> Unit,
    onPickAudio: () -> Unit,
    onPickImage: () -> Unit
) {
    val palette = paletteFor(uiState.accentMode)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        LiquidGlassCard(
            modifier = Modifier.fillMaxWidth(),
            cornerRadius = 26.dp,
            strong = true
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "📂 بث ملفات الهاتف المحلية",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 19.sp
                )
                Text(
                    "اختر فيديو أو صوت أو صورة من ذاكرة هاتفك لبثها فوراً بجودتها الأصلية مع دعم التقديم والترجيع (HTTP Range).",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(4.dp))
                LiquidGlassButton(
                    text = "اختيار فيديو من الهاتف",
                    emoji = "🎥",
                    accentColor = palette.primary,
                    onClick = onPickVideo,
                    modifier = Modifier.fillMaxWidth()
                )
                LiquidGlassButton(
                    text = "اختيار ملف صوتي / موسيقى",
                    emoji = "🎵",
                    accentColor = palette.secondary,
                    onClick = onPickAudio,
                    modifier = Modifier.fillMaxWidth()
                )
                LiquidGlassButton(
                    text = "اختيار صورة للعرض على التلفاز",
                    emoji = "🖼️",
                    accentColor = palette.primary,
                    onClick = onPickImage,
                    modifier = Modifier.fillMaxWidth(),
                    selected = false
                )
            }
        }

        LiquidGlassCard(
            modifier = Modifier.fillMaxWidth(),
            cornerRadius = 22.dp
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "🌐 رابط مستقبل الويب",
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "http://${uiState.localIp}:${uiState.serverPort}",
                    color = palette.secondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    "يعمل على أي تلفاز ذكي بدون تثبيت تطبيقات إضافية، أو اختر تلفازك مباشرة من زر الأجهزة (DLNA) في الأعلى.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}
