package com.dzcast.app.iptv

import com.dzcast.app.model.IptvChannel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

object M3uParser {

    suspend fun loadFromUrl(urlString: String): List<IptvChannel> = withContext(Dispatchers.IO) {
        val trimmed = urlString.trim()
        if (!trimmed.startsWith("http")) return@withContext emptyList()
        if (trimmed.lowercase().endsWith(".m3u8") || trimmed.lowercase().endsWith(".mp4")) {
            return@withContext listOf(
                IptvChannel(name = "بث مباشر (رابط مباشر)", group = "مباشر", url = trimmed)
            )
        }
        try {
            val conn = (URL(trimmed).openConnection() as HttpURLConnection).apply {
                connectTimeout = 5000
                readTimeout = 8000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "DZCast/1.0")
            }
            val content = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            parseContent(content)
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun parseContent(text: String): List<IptvChannel> {
        val channels = mutableListOf<IptvChannel>()
        var currentName = "قناة بث"
        var currentGroup = "عام"

        text.lines().forEach { raw ->
            val line = raw.trim()
            if (line.startsWith("#EXTINF", ignoreCase = true)) {
                currentGroup = Regex("group-title="([^"]+)"")
                    .find(line)?.groupValues?.getOrNull(1)?.trim() ?: "عام"
                currentName = line.substringAfterLast(",", "قناة بث").trim()
            } else if (line.startsWith("http://") || line.startsWith("https://")) {
                channels.add(IptvChannel(name = currentName, group = currentGroup, url = line))
                currentName = "قناة بث"
                currentGroup = "عام"
            }
        }
        return channels
    }
}
