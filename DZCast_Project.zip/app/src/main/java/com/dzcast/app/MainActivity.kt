package com.dzcast.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material.icons.rounded.CastConnected
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.dzcast.app.model.CastStateHolder
import com.dzcast.app.network.DlnaManager
import com.dzcast.app.service.CastServerService
import com.dzcast.app.service.ScreenMirrorService
import com.dzcast.app.ui.components.AmbientLiquidBackground
import com.dzcast.app.ui.components.LiquidGlassCard
import com.dzcast.app.ui.screens.BrowserScreen
import com.dzcast.app.ui.screens.DevicesAndRemoteSheet
import com.dzcast.app.ui.screens.IptvScreen
import com.dzcast.app.ui.screens.LocalMediaScreen
import com.dzcast.app.ui.screens.ScreenMirrorScreen
import com.dzcast.app.ui.theme.DZCastTheme
import com.dzcast.app.ui.theme.TextSecondary
import com.dzcast.app.ui.theme.paletteFor
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startCastServerService()

        setContent {
            val uiState by CastStateHolder.state.collectAsState()
            val scope = rememberCoroutineScope()
            var selectedTab by remember { mutableIntStateOf(0) }
            var showDevicesSheet by remember { mutableStateOf(false) }

            val notifPermissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestPermission()
            ) { }

            LaunchedEffect(Unit) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }

            val mirrorLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.StartActivityForResult()
            ) { result ->
                if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                    val intent = Intent(this, ScreenMirrorService::class.java).apply {
                        action = ScreenMirrorService.ACTION_START
                        putExtra(ScreenMirrorService.EXTRA_RESULT_CODE, result.resultCode)
                        putExtra(ScreenMirrorService.EXTRA_RESULT_DATA, result.data)
                    }
                    ContextCompat.startForegroundService(this, intent)
                }
            }

            fun castUrl(title: String, url: String, mime: String) {
                CastStateHolder.setActiveWebMedia(title, url, mime)
                val targetDlna = CastStateHolder.state.value.selectedDlnaDevice
                if (targetDlna != null) {
                    scope.launch {
                        DlnaManager.castMediaToDevice(targetDlna, url, title)
                    }
                }
            }

            fun castLocal(uri: Uri, fallbackMime: String) {
                val mime = contentResolver.getType(uri) ?: fallbackMime
                val name = queryFileName(uri) ?: "ملف محلي"
                CastStateHolder.setActiveLocalMedia(name, uri, mime)
                val current = CastStateHolder.state.value
                val targetDlna = current.selectedDlnaDevice
                if (targetDlna != null) {
                    scope.launch {
                        DlnaManager.castMediaToDevice(targetDlna, current.activeCast.url, name)
                    }
                }
            }

            val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                uri?.let { castLocal(it, "video/mp4") }
            }
            val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                uri?.let { castLocal(it, "audio/mpeg") }
            }
            val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                uri?.let { castLocal(it, "image/jpeg") }
            }

            DZCastTheme(accentMode = uiState.accentMode) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val palette = paletteFor(uiState.accentMode)
                    AmbientLiquidBackground(accentMode = uiState.accentMode) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .statusBarsPadding()
                                .navigationBarsPadding()
                        ) {
                            // Top Liquid Glass Header
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "DZ Cast 🇩🇿",
                                        color = Color.White,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 21.sp
                                    )
                                    Text(
                                        text = uiState.statusMessage,
                                        color = TextSecondary,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                LiquidGlassCard(
                                    cornerRadius = 18.dp,
                                    strong = true,
                                    tint = if (uiState.selectedDlnaDevice != null) palette.primary else palette.secondary,
                                    modifier = Modifier.clickable { showDevicesSheet = true }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (uiState.selectedDlnaDevice != null || uiState.isMirroring) {
                                                Icons.Rounded.CastConnected
                                            } else {
                                                Icons.Rounded.Cast
                                            },
                                            contentDescription = "الأجهزة",
                                            tint = Color.White
                                        )
                                        Text(
                                            text = uiState.selectedDlnaDevice?.name?.take(10) ?: "الأجهزة",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }

                            // Main Content Area
                            Box(modifier = Modifier.weight(1f)) {
                                when (selectedTab) {
                                    0 -> BrowserScreen(
                                        uiState = uiState,
                                        onCastMedia = { media ->
                                            val mime = when (media.type) {
                                                "HLS" -> "application/x-mpegURL"
                                                "AUDIO" -> "audio/mpeg"
                                                else -> "video/mp4"
                                            }
                                            castUrl(media.title, media.url, mime)
                                        }
                                    )
                                    1 -> ScreenMirrorScreen(
                                        uiState = uiState,
                                        onStartMirror = {
                                            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                                            mirrorLauncher.launch(mpm.createScreenCaptureIntent())
                                        },
                                        onStopMirror = {
                                            val stopIntent = Intent(this@MainActivity, ScreenMirrorService::class.java).apply {
                                                action = ScreenMirrorService.ACTION_STOP
                                            }
                                            startService(stopIntent)
                                        }
                                    )
                                    2 -> LocalMediaScreen(
                                        uiState = uiState,
                                        onPickVideo = { pickVideo.launch(arrayOf("video/*")) },
                                        onPickAudio = { pickAudio.launch(arrayOf("audio/*")) },
                                        onPickImage = { pickImage.launch(arrayOf("image/*")) }
                                    )
                                    else -> IptvScreen(
                                        uiState = uiState,
                                        onCastChannel = { ch ->
                                            castUrl(ch.name, ch.url, "application/x-mpegURL")
                                        }
                                    )
                                }
                            }

                            Spacer(Modifier.height(6.dp))

                            // Floating iOS 27 Liquid Glass Pill Tab Bar
                            LiquidGlassCard(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                cornerRadius = 28.dp,
                                strong = true
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(6.dp),
                                    horizontalArrangement = Arrangement.SpaceEvenly
                                ) {
                                    val tabs = listOf(
                                        "🌐" to "المتصفح",
                                        "📱" to "بث الشاشة",
                                        "📂" to "ملفاتي",
                                        "📺" to "IPTV"
                                    )
                                    tabs.forEachIndexed { index, (emoji, label) ->
                                        val isSel = selectedTab == index
                                        LiquidGlassCard(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clickable { selectedTab = index },
                                            cornerRadius = 22.dp,
                                            strong = isSel,
                                            tint = if (isSel) palette.primary else Color.Transparent
                                        ) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 8.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally
                                            ) {
                                                Text(emoji, fontSize = 16.sp)
                                                Text(
                                                    label,
                                                    color = if (isSel) Color.White else TextSecondary,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (showDevicesSheet) {
                        DevicesAndRemoteSheet(
                            uiState = uiState,
                            onDismiss = { showDevicesSheet = false },
                            onScanDlna = {
                                scope.launch {
                                    CastStateHolder.update { it.copy(isScanningDevices = true) }
                                    val found = DlnaManager.discoverDevices()
                                    CastStateHolder.update {
                                        it.copy(
                                            dlnaDevices = found,
                                            isScanningDevices = false,
                                            statusMessage = if (found.isEmpty()) {
                                                "لم يتم العثور على أجهزة DLNA، استخدم مستقبل الويب"
                                            } else {
                                                "تم العثور على ${found.size} جهاز تلفاز"
                                            }
                                        )
                                    }
                                }
                            },
                            onSelectDlna = { dev ->
                                CastStateHolder.update {
                                    it.copy(
                                        selectedDlnaDevice = dev,
                                        statusMessage = if (dev != null) "متصل بـ ${dev.name}" else "متصل بمستقبل الويب"
                                    )
                                }
                            },
                            onRemoteAction = { cmd, delta ->
                                CastStateHolder.sendRemoteCommand(cmd, delta)
                                val dlna = CastStateHolder.state.value.selectedDlnaDevice
                                if (dlna != null) {
                                    scope.launch {
                                        when (cmd) {
                                            "PLAY" -> DlnaManager.play(dlna)
                                            "PAUSE" -> DlnaManager.pause(dlna)
                                            "STOP" -> DlnaManager.stop(dlna)
                                        }
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    private fun startCastServerService() {
        val intent = Intent(this, CastServerService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun queryFileName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
            }
        } catch (_: Exception) {
            null
        }
    }
}
