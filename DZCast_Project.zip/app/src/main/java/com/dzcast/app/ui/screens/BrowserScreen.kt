package com.dzcast.app.ui.screens

import android.annotation.SuppressLint
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material.icons.rounded.DesktopWindows
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.dzcast.app.browser.AdBlocker
import com.dzcast.app.browser.MediaSniffer
import com.dzcast.app.model.AppUiState
import com.dzcast.app.model.BookmarkItem
import com.dzcast.app.model.CastStateHolder
import com.dzcast.app.model.DetectedMedia
import com.dzcast.app.ui.components.LiquidGlassButton
import com.dzcast.app.ui.components.LiquidGlassCard
import com.dzcast.app.ui.theme.TextSecondary
import com.dzcast.app.ui.theme.paletteFor
import java.io.ByteArrayInputStream

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserScreen(
    uiState: AppUiState,
    onCastMedia: (DetectedMedia) -> Unit
) {
    val palette = paletteFor(uiState.accentMode)
    var urlInput by remember { mutableStateOf("https://www.google.com") }
    var desktopMode by remember { mutableStateOf(false) }
    var loadProgress by remember { mutableIntStateOf(100) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var showMediaSheet by remember { mutableStateOf(false) }

    fun navigate(raw: String) {
        val trimmed = raw.trim()
        val target = when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            trimmed.contains(".") && !trimmed.contains(" ") -> "https://$trimmed"
            else -> "https://www.google.com/search?q=${trimmed.replace(" ", "+")}"
        }
        urlInput = target
        webViewRef?.loadUrl(target)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp)
    ) {
        // Glass URL bar + controls
        LiquidGlassCard(
            modifier = Modifier.fillMaxWidth(),
            cornerRadius = 22.dp,
            strong = true
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        singleLine = true,
                        placeholder = { Text("ابحث أو الصق رابط موقع الفيديو...", fontSize = 13.sp) },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { navigate(urlInput) }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = palette.primary,
                            unfocusedBorderColor = Color(0x33FFFFFF),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(6.dp))
                    IconButton(onClick = { webViewRef?.reload() }) {
                        Icon(Icons.Rounded.Refresh, contentDescription = "تحديث", tint = Color.White)
                    }
                }

                Spacer(Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { if (webViewRef?.canGoBack() == true) webViewRef?.goBack() }) {
                            Icon(Icons.Rounded.ArrowForward, contentDescription = "رجوع", tint = Color.White)
                        }
                        IconButton(onClick = { if (webViewRef?.canGoForward() == true) webViewRef?.goForward() }) {
                            Icon(Icons.Rounded.ArrowBack, contentDescription = "تقدم", tint = Color.White)
                        }
                        IconButton(onClick = {
                            desktopMode = !desktopMode
                            webViewRef?.settings?.userAgentString = if (desktopMode) {
                                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
                            } else {
                                WebSettings.getDefaultUserAgent(webViewRef!!.context)
                            }
                            webViewRef?.reload()
                        }) {
                            Icon(
                                Icons.Rounded.DesktopWindows,
                                contentDescription = "وضع الكمبيوتر",
                                tint = if (desktopMode) palette.primary else TextSecondary
                            )
                        }
                        IconButton(onClick = {
                            val title = webViewRef?.title?.take(22) ?: "موقع"
                            val currentUrl = webViewRef?.url ?: urlInput
                            CastStateHolder.update { st ->
                                if (st.bookmarks.any { it.url == currentUrl }) st
                                else st.copy(bookmarks = listOf(BookmarkItem(title, currentUrl)) + st.bookmarks)
                            }
                        }) {
                            Icon(Icons.Rounded.BookmarkAdd, contentDescription = "حفظ", tint = Color.White)
                        }
                    }

                    Text(
                        text = "🛡️ حظر ${uiState.blockedAdsCount} إعلان",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    items(uiState.bookmarks) { bm ->
                        LiquidGlassCard(
                            cornerRadius = 14.dp,
                            modifier = Modifier.clickable { navigate(bm.url) }
                        ) {
                            Text(
                                text = "⭐ ${bm.title}",
                                color = Color.White,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }
        }

        if (loadProgress in 1..99) {
            LinearProgressIndicator(
                progress = { loadProgress / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                color = palette.primary,
                trackColor = Color(0x22FFFFFF)
            )
        } else {
            Spacer(Modifier.height(8.dp))
        }

        // WebView + Floating Detected Media Pill
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            LiquidGlassCard(
                modifier = Modifier.fillMaxSize(),
                cornerRadius = 22.dp
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { context ->
                        WebView(context).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.mediaPlaybackRequiresUserGesture = false
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

                            addJavascriptInterface(object {
                                @JavascriptInterface
                                fun onMediaFound(url: String, title: String) {
                                    MediaSniffer.inspectUrl(url, title)?.let {
                                        CastStateHolder.addDetectedMedia(it)
                                    }
                                }
                            }, "DZCastBridge")

                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    loadProgress = newProgress
                                }
                            }

                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    if (!url.isNullOrBlank()) urlInput = url
                                    view?.evaluateJavascript(MediaSniffer.JS_SCANNER, null)
                                }

                                override fun shouldInterceptRequest(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): WebResourceResponse? {
                                    val reqUrl = request?.url?.toString() ?: return null
                                    if (AdBlocker.isAdUrl(reqUrl)) {
                                        CastStateHolder.incrementBlockedAds()
                                        return WebResourceResponse(
                                            "text/plain",
                                            "utf-8",
                                            ByteArrayInputStream(ByteArray(0))
                                        )
                                    }
                                    MediaSniffer.inspectUrl(reqUrl, null)?.let {
                                        CastStateHolder.addDetectedMedia(it)
                                    }
                                    return super.shouldInterceptRequest(view, request)
                                }
                            }

                            loadUrl(urlInput)
                            webViewRef = this
                        }
                    }
                )
            }

            // Floating Detected Media Pill
            LiquidGlassButton(
                text = if (uiState.detectedMedia.isEmpty()) {
                    "بانتظار التقاط فيديو..."
                } else {
                    "فيديوهات ملتقطة (${uiState.detectedMedia.size})"
                },
                emoji = "🎬",
                accentColor = if (uiState.detectedMedia.isNotEmpty()) palette.primary else palette.secondary,
                onClick = { showMediaSheet = true },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 12.dp)
            )
        }
    }

    if (showMediaSheet) {
        ModalBottomSheet(
            onDismissRequest = { showMediaSheet = false },
            containerColor = Color(0xFF0E111B)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "🎬 الروابط والوسائط الملتقطة",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Text(
                        "مسح",
                        color = palette.primary,
                        modifier = Modifier.clickable { CastStateHolder.clearDetectedMedia() }
                    )
                }
                Spacer(Modifier.height(12.dp))
                if (uiState.detectedMedia.isEmpty()) {
                    Text(
                        "قم بتشغيل أي فيديو داخل المتصفح وسيقوم DZ Cast بالتقاط رابطه فوراً بدون إعلانات.",
                        color = TextSecondary,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(vertical = 24.dp)
                    )
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(uiState.detectedMedia) { item ->
                            LiquidGlassCard(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onCastMedia(item)
                                        showMediaSheet = false
                                    },
                                cornerRadius = 18.dp
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            item.title,
                                            color = Color.White,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            "${item.type} • ${item.url}",
                                            color = TextSecondary,
                                            fontSize = 12.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Icon(Icons.Rounded.Cast, contentDescription = "بث", tint = palette.primary)
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
