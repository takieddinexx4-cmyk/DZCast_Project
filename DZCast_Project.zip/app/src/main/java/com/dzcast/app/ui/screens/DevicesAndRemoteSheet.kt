package com.dzcast.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dzcast.app.model.AppUiState
import com.dzcast.app.model.CastStateHolder
import com.dzcast.app.model.DlnaDevice
import com.dzcast.app.model.GlassAccentMode
import com.dzcast.app.ui.components.LiquidGlassButton
import com.dzcast.app.ui.components.LiquidGlassCard
import com.dzcast.app.ui.theme.TextSecondary
import com.dzcast.app.ui.theme.paletteFor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DevicesAndRemoteSheet(
    uiState: AppUiState,
    onDismiss: () -> Unit,
    onScanDlna: () -> Unit,
    onSelectDlna: (DlnaDevice?) -> Unit,
    onRemoteAction: (String, Int) -> Unit
) {
    val palette = paletteFor(uiState.accentMode)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0C0F19)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                "📡 أجهزة التلفاز والتحكم عن بعد",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )

            // Theme Accent Picker
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                GlassAccentMode.entries.forEach { mode ->
                    val selected = uiState.accentMode == mode
                    LiquidGlassCard(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { CastStateHolder.update { it.copy(accentMode = mode) } },
                        cornerRadius = 14.dp,
                        strong = selected,
                        tint = if (selected) palette.primary else Color.Transparent
                    ) {
                        Text(
                            text = mode.labelAr,
                            color = Color.White,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            // Web Receiver option
            LiquidGlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectDlna(null) },
                cornerRadius = 18.dp,
                strong = uiState.selectedDlnaDevice == null,
                tint = if (uiState.selectedDlnaDevice == null) palette.secondary else Color.Transparent
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        "🌐 مستقبل الويب المدمج (كل التلفازات)",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        "http://${uiState.localIp}:${uiState.serverPort}",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }

            // Scan DLNA
            LiquidGlassButton(
                text = if (uiState.isScanningDevices) "جاري البحث عن أجهزة DLNA..." else "بحث عن تلفازات DLNA على الشبكة",
                emoji = "🔍",
                accentColor = palette.primary,
                onClick = onScanDlna,
                modifier = Modifier.fillMaxWidth()
            )

            uiState.dlnaDevices.forEach { dev ->
                val isSel = uiState.selectedDlnaDevice?.location == dev.location
                LiquidGlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectDlna(dev) },
                    cornerRadius = 16.dp,
                    strong = isSel,
                    tint = if (isSel) palette.primary else Color.Transparent
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("📺 ${dev.name}", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(dev.host, color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }

            // Remote Control Deck
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 22.dp,
                strong = true
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = if (uiState.activeCast.title.isNotBlank()) {
                            "🎮 التحكم: ${uiState.activeCast.title}"
                        } else {
                            "🎮 جهاز التحكم عن بعد"
                        },
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LiquidGlassButton("15-", "⏪", palette.secondary, { onRemoteAction("SEEK", -15) }, Modifier.weight(1f), false)
                        LiquidGlassButton(
                            if (uiState.activeCast.isPlaying) "إيقاف مؤقت" else "تشغيل",
                            if (uiState.activeCast.isPlaying) "⏸️" else "▶️",
                            palette.primary,
                            { onRemoteAction(if (uiState.activeCast.isPlaying) "PAUSE" else "PLAY", 0) },
                            Modifier.weight(1.3f)
                        )
                        LiquidGlassButton("15+", "⏩", palette.secondary, { onRemoteAction("SEEK", 15) }, Modifier.weight(1f), false)
                    }
                    LiquidGlassButton(
                        text = "إيقاف البث",
                        emoji = "⏹️",
                        accentColor = palette.primary,
                        onClick = { onRemoteAction("STOP", 0) },
                        modifier = Modifier.fillMaxWidth(),
                        selected = false
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🔊 ${uiState.activeCast.volume}%", color = TextSecondary, fontSize = 12.sp)
                        Slider(
                            value = uiState.activeCast.volume.toFloat(),
                            onValueChange = { vol ->
                                CastStateHolder.sendRemoteCommand("VOLUME", newVolume = vol.toInt())
                            },
                            valueRange = 0f..100f,
                            modifier = Modifier.weight(1f).padding(start = 10.dp),
                            colors = SliderDefaults.colors(thumbColor = palette.primary, activeTrackColor = palette.primary)
                        )
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
        }
    }
}
