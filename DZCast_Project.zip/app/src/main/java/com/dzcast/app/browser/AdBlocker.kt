package com.dzcast.app.browser

import android.net.Uri

object AdBlocker {
    private val blockedHosts = setOf(
        "doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "adservice.google.com",
        "pagead2.googlesyndication.com",
        "ads.yahoo.com",
        "adnxs.com",
        "taboola.com",
        "outbrain.com",
        "popads.net",
        "popcash.net",
        "propellerads.com",
        "exoclick.com",
        "juicyads.com",
        "mgid.com",
        "adsterra.com",
        "hilltopads.net",
        "revcontent.com",
        "amazon-adsystem.com",
        "facebook.net"
    )

    fun isAdUrl(url: String): Boolean {
        val host = Uri.parse(url).host?.lowercase() ?: return false
        return blockedHosts.any { blocked ->
            host == blocked || host.endsWith(".$blocked")
        }
    }
}
