package com.dzcast.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dzcast.app.iptv.M3uParser
import com.dzcast.app.model.AppUiState
import com.dzcast.app.model.CastStateHolder
import com.dzcast.app.model.IptvChannel
import com.dzcast.app.ui.components.LiquidGlassButton
import com.dzcast.app.ui.components.LiquidGlassCard
import com.dzcast.app.ui.theme.TextSecondary
import com.dzcast.app.ui.theme.paletteFor
import kotlinx.coroutines.launch

@Composable
fun IptvScreen(
    uiState: AppUiState,
    onCastChannel: (IptvChannel) -> Unit
) {
    val palette = paletteFor(uiState.accentMode)
    val scope = rememberCoroutineScope()
    var playlistUrl by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    val filtered = remember(uiState.iptvChannels, searchQuery) {
        if (searchQuery.isBlank()) uiState.iptvChannels
        else uiState.iptvChannels.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                it.group.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        LiquidGlassCard(
            modifier = Modifier.fillMaxWidth(),
            cornerRadius = 24.dp,
            strong = true
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "📺 قوائم IPTV وروابط M3U / M3U8",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                OutlinedTextField(
                    value = playlistUrl,
                    onValueChange = { playlistUrl = it },
                    singleLine = true,
                    placeholder = { Text("الصق رابط قائمة .m3u أو بث مباشر .m3u8", fontSize = 13.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.primary,
                        unfocusedBorderColor = Color(0x33FFFFFF),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                LiquidGlassButton(
                    text = if (isLoading) "جاري التحميل..." else "تحميل القائمة / بث الرابط",
                    emoji = "⚡",
                    accentColor = palette.secondary,
                    onClick = {
                        if (playlistUrl.isNotBlank() && !isLoading) {
                            isLoading = true
                            scope.launch {
                                val loaded = M3uParser.loadFromUrl(playlistUrl)
                                CastStateHolder.update {
                                    it.copy(
                                        iptvChannels = loaded,
                                        statusMessage = if (loaded.isNotEmpty()) {
                                            "تم تحميل ${loaded.size} قناة"
                                        } else {
                                            "تعذر قراءة القائمة، تحقق من الرابط"
                                        }
                                    )
                                }
                                isLoading = false
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        if (uiState.iptvChannels.isNotEmpty()) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                singleLine = true,
                placeholder = { Text("🔍 ابحث عن قناة...", fontSize = 13.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = palette.secondary,
                    unfocusedBorderColor = Color(0x33FFFFFF),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth()
            )

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filtered) { ch ->
                    LiquidGlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onCastChannel(ch) },
                        cornerRadius = 18.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    ch.name,
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    ch.group,
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                            Icon(Icons.Rounded.Cast, contentDescription = "بث", tint = palette.primary)
                        }
                    }
                }
            }
        } else {
            Spacer(Modifier.height(12.dp))
        }
    }
}
