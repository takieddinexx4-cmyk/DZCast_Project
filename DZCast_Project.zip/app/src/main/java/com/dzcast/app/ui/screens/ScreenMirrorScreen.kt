package com.dzcast.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dzcast.app.model.AppUiState
import com.dzcast.app.model.CastStateHolder
import com.dzcast.app.model.MirrorQuality
import com.dzcast.app.ui.components.LiquidGlassButton
import com.dzcast.app.ui.components.LiquidGlassCard
import com.dzcast.app.ui.theme.TextSecondary
import com.dzcast.app.ui.theme.paletteFor

@Composable
fun ScreenMirrorScreen(
    uiState: AppUiState,
    onStartMirror: () -> Unit,
    onStopMirror: () -> Unit
) {
    val palette = paletteFor(uiState.accentMode)
    val mirrorUrl = "http://${uiState.localIp}:${uiState.serverPort}/mirror"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Live Card
        LiquidGlassCard(
            modifier = Modifier.fillMaxWidth(),
            cornerRadius = 28.dp,
            strong = true,
            tint = if (uiState.isMirroring) palette.primary else palette.secondary
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = if (uiState.isMirroring) "🔴 بث الشاشة قيد التشغيل الآن" else "📱 بث شاشة الهاتف إلى التلفاز",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 19.sp
                )
                Text(
                    text = "افتح هذا الرابط من متصفح التلفاز الذكي (Samsung / LG / Android TV / Condor / Brandt) أو الكمبيوتر على نفس شبكة Wi-Fi:",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                LiquidGlassCard(cornerRadius = 16.dp) {
                    Text(
                        text = mirrorUrl,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }

                Spacer(Modifier.height(4.dp))

                if (uiState.isMirroring) {
                    LiquidGlassButton(
                        text = "إيقاف بث الشاشة",
                        emoji = "⏹️",
                        accentColor = palette.primary,
                        onClick = onStopMirror,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    LiquidGlassButton(
                        text = "بدء بث شاشة الهاتف (${uiState.mirrorQuality.label})",
                        emoji = "📡",
                        accentColor = palette.primary,
                        onClick = onStartMirror,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Quality Selector
        LiquidGlassCard(
            modifier = Modifier.fillMaxWidth(),
            cornerRadius = 24.dp
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "🎚️ اختيار دقة وجودة البث",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                val rows = MirrorQuality.entries.chunked(2)
                rows.forEach { pair ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        pair.forEach { q ->
                            val isSelected = uiState.mirrorQuality == q
                            LiquidGlassCard(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        CastStateHolder.update {
                                            it.copy(
                                                mirrorQuality = q,
                                                mirrorFps = q.defaultFps,
                                                mirrorJpegQuality = q.defaultJpegQuality
                                            )
                                        }
                                    },
                                cornerRadius = 18.dp,
                                strong = isSelected,
                                tint = if (isSelected) palette.primary else Color.Transparent
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalAlignment = Alignment.Start
                                ) {
                                    Text(
                                        text = q.label,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        text = "${q.subtitle} • ${q.defaultFps} FPS",
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Fine-tuning FPS & Compression
        LiquidGlassCard(
            modifier = Modifier.fillMaxWidth(),
            cornerRadius = 24.dp
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "⚙️ ضبط متقدم للسلاسة والسرعة",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    "معدل الإطارات: ${uiState.mirrorFps} FPS",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Slider(
                    value = uiState.mirrorFps.toFloat(),
                    onValueChange = { v -> CastStateHolder.update { it.copy(mirrorFps = v.toInt()) } },
                    valueRange = 10f..30f,
                    colors = SliderDefaults.colors(thumbColor = palette.primary, activeTrackColor = palette.primary)
                )

                Text(
                    "وضوح الصورة (JPEG): ${uiState.mirrorJpegQuality}%",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Slider(
                    value = uiState.mirrorJpegQuality.toFloat(),
                    onValueChange = { v -> CastStateHolder.update { it.copy(mirrorJpegQuality = v.toInt()) } },
                    valueRange = 45f..90f,
                    colors = SliderDefaults.colors(thumbColor = palette.secondary, activeTrackColor = palette.secondary)
                )
            }
        }

        Spacer(Modifier.height(16.dp))
    }
}
