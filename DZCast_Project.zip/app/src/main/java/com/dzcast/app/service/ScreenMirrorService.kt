package com.dzcast.app.service

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.dzcast.app.model.CastStateHolder
import com.dzcast.app.model.MirrorQuality
import java.io.ByteArrayOutputStream

class ScreenMirrorService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var workerHandler: Handler? = null
    private var lastFrameTimeMs = 0L

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopMirroring()
            stopSelf()
            return START_NOT_STICKY
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode != Activity.RESULT_OK || resultData == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val state = CastStateHolder.state.value
        val notif = buildNotification("بث الشاشة نشط (${state.mirrorQuality.label}) على http://${state.localIp}:${state.serverPort}/mirror")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notif)
        }

        startMirroring(resultCode, resultData, state.mirrorQuality)
        return START_NOT_STICKY
    }

    private fun startMirroring(resultCode: Int, data: Intent, quality: MirrorQuality) {
        stopMirroring()
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = mpm.getMediaProjection(resultCode, data) ?: run {
            stopSelf()
            return
        }
        mediaProjection = projection

        workerThread = HandlerThread("DZCastMirrorThread").apply { start() }
        workerHandler = Handler(workerThread!!.looper)

        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopMirroring()
                stopSelf()
            }
        }, workerHandler)

        val metrics = resources.displayMetrics
        val isPortrait = metrics.heightPixels >= metrics.widthPixels
        val targetWidth = if (isPortrait) quality.height else quality.width
        val targetHeight = if (isPortrait) quality.width else quality.height

        imageReader = ImageReader.newInstance(
            targetWidth,
            targetHeight,
            PixelFormat.RGBA_8888,
            2
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val currentState = CastStateHolder.state.value
            val minIntervalMs = (1000L / currentState.mirrorFps.coerceIn(10, 30))
            val now = System.currentTimeMillis()
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                if (now - lastFrameTimeMs < minIntervalMs) return@setOnImageAvailableListener
                lastFrameTimeMs = now

                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * targetWidth

                val paddedBitmap = Bitmap.createBitmap(
                    targetWidth + rowPadding / pixelStride,
                    targetHeight,
                    Bitmap.Config.ARGB_8888
                )
                paddedBitmap.copyPixelsFromBuffer(buffer)

                val finalBitmap = if (rowPadding > 0) {
                    Bitmap.createBitmap(paddedBitmap, 0, 0, targetWidth, targetHeight).also {
                        paddedBitmap.recycle()
                    }
                } else {
                    paddedBitmap
                }

                val baos = ByteArrayOutputStream()
                finalBitmap.compress(
                    Bitmap.CompressFormat.JPEG,
                    currentState.mirrorJpegQuality.coerceIn(40, 92),
                    baos
                )
                finalBitmap.recycle()

                CastStateHolder.latestMirrorFrame.set(baos.toByteArray())
                val count = CastStateHolder.latestFrameCounter.incrementAndGet()
                if (count % 15L == 0L) {
                    CastStateHolder.update { it.copy(mirrorFramesSent = count) }
                }
            } catch (_: Exception) {
                // skip dropped frame
            } finally {
                image.close()
            }
        }, workerHandler)

        virtualDisplay = projection.createVirtualDisplay(
            "DZCastVirtualDisplay",
            targetWidth,
            targetHeight,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            workerHandler
        )

        CastStateHolder.update {
            it.copy(
                isMirroring = true,
                statusMessage = "بث شاشة الهاتف نشط بجودة ${quality.label}"
            )
        }
    }

    private fun stopMirroring() {
        try {
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection?.stop()
            workerThread?.quitSafely()
        } catch (_: Exception) {
        }
        virtualDisplay = null
        imageReader = null
        mediaProjection = null
        workerThread = null
        workerHandler = null
        CastStateHolder.update {
            it.copy(isMirroring = false, statusMessage = "تم إيقاف بث الشاشة")
        }
    }

    override fun onDestroy() {
        stopMirroring()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "DZ Cast Screen Mirroring",
            NotificationManager.IMPORTANCE_LOW
        )
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("DZ Cast — بث الشاشة المباشر 🇩🇿")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_START = "com.dzcast.app.ACTION_START_MIRROR"
        const val ACTION_STOP = "com.dzcast.app.ACTION_STOP_MIRROR"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "dzcast_mirror_channel"
        private const val NOTIF_ID = 1002
    }
}
