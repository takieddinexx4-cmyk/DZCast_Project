package com.dzcast.app.network

import android.content.Context
import com.dzcast.app.model.CastStateHolder
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class LocalCastServer(
    private val context: Context,
    private val port: Int = 8080
) {
    private val running = AtomicBoolean(false)
    private var serverSocket: ServerSocket? = null
    private val executor = Executors.newCachedThreadPool()

    fun start() {
        if (!running.compareAndSet(false, true)) return
        executor.execute {
            try {
                serverSocket = ServerSocket(port)
                while (running.get()) {
                    val client = serverSocket?.accept() ?: break
                    executor.execute { handleClient(client) }
                }
            } catch (_: Exception) {
                // server stopped
            }
        }
    }

    fun stop() {
        running.set(false)
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
    }

    private fun handleClient(socket: Socket) {
        socket.use { client ->
            try {
                client.soTimeout = 15000
                val reader = BufferedReader(InputStreamReader(client.getInputStream()))
                val requestLine = reader.readLine() ?: return
                val parts = requestLine.split(" ")
                if (parts.size < 2) return
                val fullPath = parts[1]
                val path = fullPath.substringBefore("?")

                val headers = mutableMapOf<String, String>()
                var line = reader.readLine()
                while (!line.isNullOrEmpty()) {
                    val idx = line.indexOf(':')
                    if (idx > 0) {
                        headers[line.substring(0, idx).trim().lowercase()] =
                            line.substring(idx + 1).trim()
                    }
                    line = reader.readLine()
                }

                val out = BufferedOutputStream(client.getOutputStream())
                when (path) {
                    "/", "/index.html" -> sendHtml(out, buildReceiverHtml())
                    "/mirror" -> sendHtml(out, buildMirrorHtml())
                    "/mirror/stream" -> streamMjpeg(out)
                    "/api/state" -> sendJson(out, buildStateJson())
                    "/media/local" -> streamLocalFile(out, headers["range"])
                    else -> sendNotFound(out)
                }
            } catch (_: Exception) {
                // client disconnected
            }
        }
    }

    private fun sendHtml(out: OutputStream, html: String) {
        val bytes = html.toByteArray(Charsets.UTF_8)
        val header = "HTTP/1.1 200 OK\r\n" +
            "Content-Type: text/html; charset=utf-8\r\n" +
            "Content-Length: ${bytes.size}\r\n" +
            "Cache-Control: no-cache\r\n" +
            "Connection: close\r\n\r\n"
        out.write(header.toByteArray())
        out.write(bytes)
        out.flush()
    }

    private fun sendJson(out: OutputStream, json: String) {
        val bytes = json.toByteArray(Charsets.UTF_8)
        val header = "HTTP/1.1 200 OK\r\n" +
            "Content-Type: application/json; charset=utf-8\r\n" +
            "Access-Control-Allow-Origin: *\r\n" +
            "Cache-Control: no-cache\r\n" +
            "Content-Length: ${bytes.size}\r\n" +
            "Connection: close\r\n\r\n"
        out.write(header.toByteArray())
        out.write(bytes)
        out.flush()
    }

    private fun sendNotFound(out: OutputStream) {
        val body = "404 Not Found - DZ Cast".toByteArray()
        val header = "HTTP/1.1 404 Not Found\r\nContent-Length: ${body.size}\r\nConnection: close\r\n\r\n"
        out.write(header.toByteArray())
        out.write(body)
        out.flush()
    }

    private fun streamMjpeg(out: OutputStream) {
        val header = "HTTP/1.1 200 OK\r\n" +
            "Content-Type: multipart/x-mixed-replace; boundary=dzcastframe\r\n" +
            "Cache-Control: no-cache, no-store, must-revalidate\r\n" +
            "Pragma: no-cache\r\n" +
            "Connection: keep-alive\r\n\r\n"
        out.write(header.toByteArray())
        out.flush()

        var lastSent = -1L
        while (running.get()) {
            val currentCounter = CastStateHolder.latestFrameCounter.get()
            val frame = CastStateHolder.latestMirrorFrame.get()
            if (frame != null && currentCounter != lastSent) {
                lastSent = currentCounter
                val partHeader = "--dzcastframe\r\n" +
                    "Content-Type: image/jpeg\r\n" +
                    "Content-Length: ${frame.size}\r\n\r\n"
                out.write(partHeader.toByteArray())
                out.write(frame)
                out.write("\r\n".toByteArray())
                out.flush()
            } else {
                Thread.sleep(15)
            }
        }
    }

    private fun streamLocalFile(out: OutputStream, rangeHeader: String?) {
        val cast = CastStateHolder.state.value.activeCast
        val uri = cast.localUri ?: run {
            sendNotFound(out)
            return
        }
        val mime = cast.mimeType.ifBlank { "video/mp4" }
        val afd = context.contentResolver.openAssetFileDescriptor(uri, "r") ?: run {
            sendNotFound(out)
            return
        }
        afd.use { descriptor ->
            val fileLength = descriptor.length
            var start = 0L
            var end = if (fileLength > 0) fileLength - 1 else -1L
            var partial = false

            if (!rangeHeader.isNullOrBlank() && rangeHeader.startsWith("bytes=") && fileLength > 0) {
                val rangeSpec = rangeHeader.removePrefix("bytes=").substringBefore(",")
                val bounds = rangeSpec.split("-")
                start = bounds.getOrNull(0)?.toLongOrNull() ?: 0L
                val parsedEnd = bounds.getOrNull(1)?.toLongOrNull()
                if (parsedEnd != null && parsedEnd < fileLength) {
                    end = parsedEnd
                }
                partial = true
            }

            val input = descriptor.createInputStream()
            input.use { stream ->
                if (start > 0) {
                    stream.skip(start)
                }
                if (partial && fileLength > 0) {
                    val contentLength = (end - start + 1).coerceAtLeast(0L)
                    val header = "HTTP/1.1 206 Partial Content\r\n" +
                        "Content-Type: $mime\r\n" +
                        "Accept-Ranges: bytes\r\n" +
                        "Content-Range: bytes $start-$end/$fileLength\r\n" +
                        "Content-Length: $contentLength\r\n" +
                        "Connection: close\r\n\r\n"
                    out.write(header.toByteArray())
                    copyBounded(stream, out, contentLength)
                } else {
                    val lengthLine = if (fileLength > 0) "Content-Length: $fileLength\r\n" else ""
                    val header = "HTTP/1.1 200 OK\r\n" +
                        "Content-Type: $mime\r\n" +
                        "Accept-Ranges: bytes\r\n" +
                        lengthLine +
                        "Connection: close\r\n\r\n"
                    out.write(header.toByteArray())
                    stream.copyTo(out, 64 * 1024)
                }
                out.flush()
            }
        }
    }

    private fun copyBounded(input: java.io.InputStream, output: OutputStream, maxBytes: Long) {
        val buf = ByteArray(64 * 1024)
        var remaining = maxBytes
        while (remaining > 0) {
            val toRead = minOf(buf.size.toLong(), remaining).toInt()
            val read = input.read(buf, 0, toRead)
            if (read <= 0) break
            output.write(buf, 0, read)
            remaining -= read
        }
    }

    private fun buildStateJson(): String {
        val st = CastStateHolder.state.value
        val c = st.activeCast
        return "{" +
            ""title":"${jsonEsc(c.title)}"," +
            ""url":"${jsonEsc(c.url)}"," +
            ""mimeType":"${jsonEsc(c.mimeType)}"," +
            ""isPlaying":${c.isPlaying}," +
            ""volume":${c.volume}," +
            ""command":"${jsonEsc(c.command)}"," +
            ""seekDeltaSec":${c.seekDeltaSec}," +
            ""commandSeq":${c.commandSeq}," +
            ""isMirroring":${st.isMirroring}" +
            "}"
    }

    private fun jsonEsc(s: String): String =
        s.replace("\\", "\\\\")
            .replace(""", "\\"")
            .replace("\n", " ")
            .replace("\r", " ")

    private fun buildReceiverHtml(): String = """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DZ Cast 🇩🇿 — مستقبل البث</title>
<script src="https://cdn.jsdelivr.net/npm/hls.js@1"></script>
<style>
  body {
    margin: 0; background: radial-gradient(circle at 20% 20%, rgba(184,50,68,.24), transparent 45%),
    radial-gradient(circle at 80% 80%, rgba(43,98,184,.28), transparent 45%), #06070c;
    color: #fff; font-family: system-ui, -apple-system, sans-serif;
    min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center;
  }
  .glass {
    width: min(94vw, 1120px); border-radius: 28px; padding: 20px;
    background: rgba(255,255,255,0.06); backdrop-filter: blur(24px);
    border: 1px solid rgba(255,255,255,0.16); box-shadow: 0 24px 60px rgba(0,0,0,0.65);
  }
  .top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; }
  .badge { padding: 6px 14px; border-radius: 999px; background: rgba(184,50,68,0.28); border: 1px solid rgba(255,255,255,0.18); font-size: 13px; }
  video, img.viewer { width: 100%; max-height: 75vh; border-radius: 18px; background: #000; display: block; }
  .btn { color: #fff; text-decoration: none; padding: 8px 16px; border-radius: 14px; background: rgba(43,98,184,0.35); border: 1px solid rgba(255,255,255,0.18); font-size: 14px; }
</style>
</head>
<body>
  <div class="glass">
    <div class="top">
      <div><strong>DZ Cast 🇩🇿</strong> <span id="title" style="opacity:.8;margin-right:8px;">في انتظار البث من هاتفك...</span></div>
      <div style="display:flex;gap:8px;align-items:center;">
        <a class="btn" href="/mirror">📱 عرض شاشة الهاتف</a>
        <span class="badge" id="status">متصل</span>
      </div>
    </div>
    <video id="player" controls autoplay playsinline></video>
    <img id="imgViewer" class="viewer" style="display:none;" />
  </div>
<script>
  const video = document.getElementById('player');
  const imgViewer = document.getElementById('imgViewer');
  const titleEl = document.getElementById('title');
  const statusEl = document.getElementById('status');
  let lastSeq = -1;
  let hls = null;

  function loadMedia(url, mime) {
    if (!url) return;
    if (mime && mime.startsWith('image/')) {
      video.pause(); video.style.display = 'none';
      imgViewer.style.display = 'block'; imgViewer.src = url;
      return;
    }
    imgViewer.style.display = 'none'; video.style.display = 'block';
    if (hls) { hls.destroy(); hls = null; }
    if (url.includes('.m3u8') && window.Hls && Hls.isSupported()) {
      hls = new Hls(); hls.loadSource(url); hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => video.play().catch(()=>{}));
    } else {
      video.src = url; video.play().catch(()=>{});
    }
  }

  async function poll() {
    try {
      const res = await fetch('/api/state');
      const st = await res.json();
      if (st.title) titleEl.textContent = st.title;
      if (st.isMirroring && !st.url) {
        window.location.href = '/mirror';
        return;
      }
      if (st.commandSeq !== lastSeq) {
        lastSeq = st.commandSeq;
        if (st.command === 'LOAD') loadMedia(st.url, st.mimeType);
        else if (st.command === 'PLAY') video.play().catch(()=>{});
        else if (st.command === 'PAUSE') video.pause();
        else if (st.command === 'STOP') { video.pause(); video.removeAttribute('src'); video.load(); }
        else if (st.command === 'SEEK') video.currentTime = Math.max(0, video.currentTime + (st.seekDeltaSec || 0));
        else if (st.command === 'VOLUME') video.volume = Math.min(1, Math.max(0, (st.volume || 80) / 100));
      }
      statusEl.textContent = st.isPlaying ? 'قيد التشغيل' : 'جاهز';
    } catch (e) { statusEl.textContent = 'إعادة اتصال...'; }
  }
  setInterval(poll, 1000);
  poll();
</script>
</body>
</html>
    """.trimIndent()

    private fun buildMirrorHtml(): String = """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DZ Cast 🇩🇿 — بث شاشة الهاتف</title>
<style>
  body {
    margin: 0; background: #05060a; color: #fff; font-family: system-ui, sans-serif;
    height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; overflow: hidden;
  }
  .hud {
    position: fixed; top: 14px; right: 14px; left: 14px; display: flex; justify-content: space-between;
    pointer-events: none; z-index: 10;
  }
  .pill {
    pointer-events: auto; padding: 8px 16px; border-radius: 999px;
    background: rgba(10,12,20,0.65); backdrop-filter: blur(18px);
    border: 1px solid rgba(255,255,255,0.18); font-size: 13px; color: #fff; text-decoration: none; cursor: pointer;
  }
  img {
    max-width: 100vw; max-height: 100vh; object-fit: contain;
  }
</style>
</head>
<body>
  <div class="hud">
    <span class="pill">🔴 مباشر — DZ Cast Mirror 🇩🇿</span>
    <div style="display:flex;gap:8px;">
      <button class="pill" onclick="document.documentElement.requestFullscreen?.()">⛶ ملء الشاشة</button>
      <a class="pill" href="/">🎬 مشغل الفيديو</a>
    </div>
  </div>
  <img src="/mirror/stream" alt="DZ Cast Screen Mirror" />
</body>
</html>
    """.trimIndent()
}
